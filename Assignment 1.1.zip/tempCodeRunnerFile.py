    b = Battle(t1, t2, BattleMode.SET)
    winner = b.commence_battle()